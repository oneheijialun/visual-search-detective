"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {pathToFileURL} = require("node:url");

const source = path.resolve(__dirname,"../dist");
const destination = path.resolve(process.argv[2] || "../visual-search-browser-qa");
assert.ok(destination !== source && !destination.startsWith(source+path.sep));
fs.mkdirSync(destination,{recursive:true});
fs.cpSync(source,destination,{recursive:true});
const fixture = fs.readFileSync(path.join(source,"index.html"),"utf8")
  .replace('<script defer src="assets/stimuli.js">','<script defer src="qa-setup.js"></script><script defer src="assets/stimuli.js">')
  .replace('<script defer src="app.js"></script>','<script defer src="app.js"></script><script defer src="qa-run.js"></script>');
fs.writeFileSync(path.join(destination,"index.html"),fixture);

const images = Object.fromEntries(fs.readdirSync(path.join(source,"assets")).filter(name=>/_[AB]\.svg$/.test(name)).map(name=>[
  name,"data:image/svg+xml;base64,"+fs.readFileSync(path.join(source,"assets",name)).toString("base64")
]));
fs.writeFileSync(path.join(destination,"qa-setup.js"),`
  LabConfig.timing = {fixationMs:50,cueMs:150,imageMs:175,blankMs:85,trialTimeoutMs:650,practiceTimeoutMs:650};
  LabConfig.upload.projectId = "QATEST";
  LabConfig.upload.endpoint = "https://example.test/api/hw2/submit";
  try { sessionStorage.removeItem("visual-search-lab:active"); } catch {}
  const posts = [];
  window.fetch = async (url,options) => {
    if (url !== LabConfig.upload.endpoint) throw Error("Unexpected network request");
    posts.push({url,method:options.method,body:JSON.parse(options.body)});
    return new Response('{"ok":true}',{headers:{"Content-Type":"application/json"}});
  };
  const images = ${JSON.stringify(images)};
`);

async function browserTests() {
  const main = document.querySelector("#main");
  const checks = [];
  const $ = selector=>document.querySelector(selector);
  function assert(value,message) {
    if (!value) throw new Error(message);
  }
  async function wait(fn, message, ms=4500) {
    const until = performance.now()+ms;
    while (performance.now()<until) {
      const found = fn();
      if (found) return found;
      await new Promise(resolve=>setTimeout(resolve,7));
    }
    throw new Error(message);
  }
  function button(id) {
    assert($(id),`Control missing: ${id}`);
    $(id).click();
  }
  function clickAt(x,y) {
    const stage = $("#stage");
    const box = stage.getBoundingClientRect();
    stage.dispatchEvent(new PointerEvent("pointerdown",{bubbles:true,isPrimary:true,pointerType:"mouse",button:0,
      clientX:box.left+x/LabDesign.width*box.width,clientY:box.top+y/LabDesign.height*box.height}));
  }
  function target(t) {
    const [x,y,w,h]=t.box;
    clickAt(x+w/2,y+h/2);
  }
  async function phase(name) {
    return wait(()=>$("#stage")?.dataset.phase===name,`Missing phase ${name}`);
  }
  function consent() {
    button("#begin");
    assert($("#agree").disabled,"Consent gate is open");
    $("#affiliation").value = "external";
    $("#affiliation").dispatchEvent(new Event("change"));
    assert($("#student-id").disabled,"External participant unexpectedly needs a student ID");
    $("#gender").value = "不愿透露";
    $("#age").value = "21";
    $("#consent-check").click();
    button("#agree");
  }
  async function pixels(source) {
    const img = new Image();
    img.src = source;
    await img.decode();
    const canvas = document.createElement("canvas");
    canvas.width=LabDesign.width;
    canvas.height=LabDesign.height;
    const ctx=canvas.getContext("2d",{willReadFrequently:true});
    ctx.drawImage(img,0,0);
    return ctx.getImageData(0,0,canvas.width,canvas.height).data;
  }

  try {
    for (const pair of Object.values(LabDesign.pairs)) {
      const [a,b] = await Promise.all([pixels(images[`${pair.id}_A.svg`]),pixels(images[`${pair.id}_B.svg`])]);
      const boxCounts = pair.targets.map(()=>0);
      for (let p=0;p<a.length;p+=4) {
        if (a[p]===b[p] && a[p+1]===b[p+1] && a[p+2]===b[p+2] && a[p+3]===b[p+3]) continue;
        const x=(p/4)%LabDesign.width;
        const y=Math.floor(p/4/LabDesign.width);
        const hit=pair.targets.findIndex(({box:[l,t,w,h]})=>x>=l && x<l+w && y>=t && y<t+h);
        assert(hit>=0,`${pair.id} differs outside a target at ${x},${y}`);
        boxCounts[hit]++;
      }
      assert(boxCounts.every(n=>n>20),`${pair.id} missing a visible change`);
    }
    checks.push("9 对刺激通过浏览器像素比对，每对恰有三个变化区域");
    consent();
    const firstId=LabData.getActive().session_id;
    button("#quit-nav");
    $("#quit-dialog").querySelector('[value="quit"]').click();
    await wait(()=>$("#begin"),"Quit failed");
    assert(!LabData.list().some(s=>s.session_id===firstId),"Withdrawn session remained");
    checks.push("知情同意和撤回通过");

    consent();
    const s=LabData.getActive();
    assert(/^\d{5}$/.test(s.participant_id),"Participant ID format");
    button("#practice");
    await phase("A");
    Object.defineProperty(document,"hidden",{configurable:true,value:true});
    document.dispatchEvent(new Event("visibilitychange"));
    delete document.hidden;
    await wait(()=>$("#retry"),"Pause not displayed");
    assert(s.interruptions.length===1,"Interrupted practice not logged");
    button("#retry");
    await phase("A");
    const practice=LabDesign.pairs[LabConfig.practicePair];
    practice.targets.forEach(target);
    await wait(()=>$("#formal"),"Practice completion missing");
    button("#formal");
    checks.push("独立练习、标签页中断与重启通过");

    for (const [i,plan] of s.assignment.trials.entries()) {
      button("#run");
      await phase("cue");
      const pair=LabDesign.pairs[plan.pairId];
      const legend = [...document.querySelectorAll(".icon-legend img")];
      const expected = LabDesign.cue(pair,plan.condition);
      if (plan.condition==="C") {
        assert(legend.map(i=>i.alt).join()===expected.items.map(i=>i.label).join(),"Graphical cue contents");
      } else if (plan.condition==="A") {
        assert(!$(".cue"),"Unexpected cue");
      } else {
        assert($(".cue strong").textContent===expected.items.join("　·　"),"Text cue contents");
      }
      await phase("A");
      if (i===0) {
        clickAt(3,3);
        target(pair.targets[0]);
        target(pair.targets[0]);
        await phase("blank1");
        target(pair.targets[1]);
        await phase("B");
        target(pair.targets[1]);
        await phase("blank2");
        await phase("A");
        target(pair.targets[2]);
      } else if (i===s.assignment.trials.length-1) {
        target(pair.targets[0]);
      } else {
        pair.targets.forEach(target);
      }
      if (i<s.assignment.trials.length-1) await wait(()=>$("#run"),"Trial did not advance");
    }
    await wait(()=>$("#upload-status")?.textContent.includes("已提交"),"Completion or mock upload missing");
    assert($("#results-report") && document.querySelectorAll(".report-chart-row").length===8,"Personal report missing");
    button('[data-concept="search"]');
    assert(!$("#concept-search").hidden && $("#concept-change").hidden,"Concept lab did not switch");
    const [first] = s.trials;
    const last = s.trials.at(-1);
    assert(first.correct_clicks===3 && first.incorrect_clicks===1 && first.duplicate_clicks===1 && first.blank_clicks===1,
      "Click categories are wrong");
    assert(first.cycle_count===1 && first.a_views===2 && first.b_views===1,"Incorrect flicker counts");
    assert(first.click_accuracy===.75,"Incorrect accuracy");
    assert(last.completion==="timeout" && last.total_rt_ms===650 && last.correct_clicks===1,"Timeout invalid");
    assert(s.trials.length===8 && s.trials.every(t=>t.trial_index>=1 && t.image_id!=="P0"),"Formal data contaminated");
    assert(posts.length===1 && posts[0].method==="POST" && posts[0].body.trials.length===8,"Wrong submission count");
    assert(posts[0].body.condition==="" && posts[0].body.trials.at(-1).correct===false && posts[0].body.project==="QATEST","Wrong submit body");
    checks.push("8 轮、四种提示、点击分类、完整循环、超时及一次模拟 POST 通过");

    const downloads=[];
    LabData.download=(name,text)=>downloads.push({name,text});
    button("#json");
    button("#csv");
    const json=JSON.parse(downloads[0].text);
    assert(json.sessions[0].trials.length===8 && downloads[1].text.trim().split("\r\n").length===9,"Bad exports");
    assert(LabData.importBundle(json)===0,"Duplicate JSON import");
    const extra=JSON.parse(JSON.stringify(json));
    extra.sessions[0].session_id=[...crypto.getRandomValues(new Uint32Array(4))].map(n=>n.toString(16).padStart(8,"0")).join("");
    assert(LabData.importBundle(extra)===1,"JSON import failed");
    button("#data-nav");
    assert($(".stats")?.textContent.includes("正式试次"),"Experimenter dashboard missing");
    $(".detail").click();
    assert(main.textContent.includes("完整循环"),"Trial detail missing");
    checks.push("CSV、JSON、去重导入和实验者视图通过");
    main.innerHTML=`<section class="panel"><h1>浏览器全流程测试通过</h1><ol>${checks.map(s=>`<li>${s}</li>`).join("")}</ol><p>本页提交由模拟接口接收。</p></section>`;
  } catch (error) {
    main.replaceChildren(Object.assign(document.createElement("h1"),{textContent:"浏览器测试失败"}),
      Object.assign(document.createElement("pre"),{textContent:error.stack}));
  }
}
fs.writeFileSync(path.join(destination,"qa-run.js"),`window.addEventListener("load",${browserTests.toString()});\n`);
console.log(pathToFileURL(path.join(destination,"index.html")).href);
