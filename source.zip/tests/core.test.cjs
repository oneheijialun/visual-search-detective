"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {test} = require("node:test");
const vm = require("node:vm");

function storage() {
  const rows = new Map();
  return {get length() { return rows.size; }, key:i=>[...rows.keys()][i],
    getItem:key=>rows.get(key)??null,setItem:(key,val)=>rows.set(key,val),removeItem:key=>rows.delete(key)};
}
let send;
const context = vm.createContext({URL,location:{href:"https://example.test/?slot=1"},
  crypto:globalThis.crypto,localStorage:storage(),sessionStorage:storage(),
  fetch:(...args)=>send(...args),AbortController,setTimeout,clearTimeout});
for (const file of ["config.js","assets/stimuli.js","design.js","data.js","results.js"]) {
  vm.runInContext(fs.readFileSync(path.join(__dirname,"../dist",file),"utf8"),context,{filename:file});
}
const D = context.LabDesign;
const cfg = context.LabConfig;
const data = context.LabData;

test("registration stays outside anonymous sessions and separate downloads can be cleared",()=>{
  assert.throws(()=>data.validateRegistration({affiliation:"campus",studentId:"",gender:"女",age:"21"}),/学号/);
  assert.throws(()=>data.validateRegistration({affiliation:"external",gender:"女",age:"21.5"}),/年龄/);
  const external = data.validateRegistration({affiliation:"external",studentId:"IGNORED",gender:"不愿透露",age:"23"});
  assert.equal(external.student_id,null);
  assert.equal(external.age,23);
  const profile = data.validateRegistration({affiliation:"campus",studentId:"TEST012345",gender:"男",age:"20"});
  const session = data.create(false);
  data.rememberRegistration(session,profile);
  assert.equal(data.getRegistration(session).student_id,"TEST012345");
  assert.doesNotMatch(JSON.stringify(data.bundle([session])),/TEST012345|student_id|gender/);
  assert.doesNotMatch(JSON.stringify(D.coursePayload(session,cfg.upload)),/TEST012345|student_id|gender/);
  data.withdraw(session);
  assert.equal(data.getRegistration(session),null);
});

test("result metrics keep timeouts separate from completion time and ignore missing first hits",()=>{
  const summary = context.LabResults.summarize([
    {completed:true,completion:"completed",first_hit_rt_ms:1000,total_rt_ms:3600,correct_clicks:3,target_count:3},
    {completed:false,completion:"timeout",first_hit_rt_ms:3200,total_rt_ms:120000,correct_clicks:1,target_count:3},
    {completed:false,completion:"timeout",first_hit_rt_ms:null,total_rt_ms:120000,correct_clicks:0,target_count:3}
  ]);
  assert.deepEqual({...summary},{
    count:3,found:4,targets:9,completed:1,timedOut:2,firstHit:2100,completeTime:3600
  });
  assert.match(context.LabResults.render(context.LabResults.exampleTrials()),/22 \/ 24/);
});

test("16 slots balance condition position, image assignment and adjacent orders",()=>{
  const counts = new Map();
  const bump = key=>counts.set(key,1+(counts.get(key)??0));
  for (let i=0;i<D.slotCount;i++) {
    const s = D.makeSchedule(i);
    assert.equal(s.trials.length,8);
    assert.equal(new Set(s.trials.map(t=>t.pairId)).size,8);
    assert.equal(s.trials.some(t=>t.pairId===cfg.practicePair),false);
    for (const c of "ABCD") assert.equal(s.trials.filter(t=>t.condition===c).length,2);
    for (const t of s.trials) bump(t.condition+":"+t.pairId);
    for (const [pos,c] of [...s.order].entries()) {
      bump(pos+":"+c);
      if (pos>0) bump(s.order[pos-1]+c);
    }
  }
  assert.equal(counts.size,60);
  assert.equal([...counts.values()].every(n=>n===4),true);
  const first = Array.from({length:4},(_,i)=>D.makeSchedule(i));
  assert.equal(new Set(first.map(a=>a.rotation)).size,4);
  assert.equal(new Set(first.map(a=>a.order)).size,4);
});

test("images share a byte-identical base with exactly three named changes and distinct hitboxes",()=>{
  for (const pair of Object.values(D.pairs)) {
    const read = suffix=>fs.readFileSync(path.join(__dirname,`../dist/assets/${pair.id}_${suffix}.svg`),"utf8");
    const [a,b] = [read("A"),read("B")];
    const withoutChanges = svg=>svg.replace(/(<g id="change-[^"]+">).*?(?=<g id="change-|<\/svg>|<\/g><\/svg>)/g,"$1");
    assert.equal(withoutChanges(a),withoutChanges(b),pair.id);
    const parts = svg=>[...svg.matchAll(/<g id="change-([^"]+)">(.*?)(?=<g id="change-|<\/svg>|<\/g><\/svg>)/g)];
    const aa = parts(a), bb = parts(b);
    assert.equal(aa.length,3,pair.id);
    assert.equal(bb.length,3,pair.id);
    const text = D.cue(pair,"B");
    const graphics = D.cue(pair,"C");
    const misleading = D.cue(pair,"D");
    assert.equal(text.items.join(),graphics.items.map(x=>x.label).join());
    assert.equal(misleading.items.length,3);
    for (const [i,t] of pair.targets.entries()) {
      const [x,y,w,h] = t.box;
      assert.equal(aa[i][1],t.id);
      assert.equal(bb[i][1],t.id);
      assert.notEqual(aa[i][2],bb[i][2]);
      assert.equal(D.targetsAt(pair,x+w/2,y+h/2).id,t.id);
      assert.equal(misleading.items.includes(t.label),false);
      assert.ok(x>=0 && y>=0 && x+w<=D.width && y+h<=D.height);
      for (const u of pair.targets.slice(i+1)) {
        const [a,b,c,d] = u.box;
        assert.ok(x+w<=a || a+c<=x || y+h<=b || b+d<=y,`${pair.id}: ${t.id} and ${u.id} overlap`);
      }
    }
  }
});

test("flicker starts at image A and counts completed cycles and a capped timeout",()=>{
  const clock = D.createClock(cfg.timing,1300,0);
  assert.equal(clock.step(499),null);
  assert.equal(clock.step(500),"cue");
  assert.equal(clock.elapsed(999),null);
  assert.equal(clock.step(3500),"A");
  assert.equal(clock.elapsed(3500),0);
  assert.equal(clock.step(4000),"blank1");
  assert.equal(clock.step(4100),"B");
  assert.equal(clock.step(4600),"blank2");
  assert.equal(clock.step(4700),"A");
  assert.equal(clock.counts().cycle_count,1);
  assert.equal(clock.counts().cycles_started,2);
  assert.equal(clock.counts().b_views,1);
  assert.equal(clock.step(4805),"timeout");
  assert.equal(clock.elapsed(4805),1300);
});

test("course POST runs only for completed sessions, avoids duplicate sends, and preserves backup data",async ()=>{
  const s = data.create(false);
  assert.match(s.participant_id,/^\d{5}$/);
  assert.equal(s.assignment.slot,1);
  let attempts = 0;
  send = async (url,options)=>{
    attempts++;
    const payload = JSON.parse(options.body);
    assert.equal(url,cfg.upload.endpoint);
    assert.equal(options.method,"POST");
    assert.equal(payload.project,cfg.upload.projectId);
    assert.equal(payload.participant,s.participant_id);
    assert.equal(payload.experiment,cfg.upload.experiment);
    assert.equal(payload.condition,"");
    assert.deepEqual(payload.trials.map(t=>[t.cond,t.rt,t.correct]),[["A",510,true]]);
    assert.equal("gaze" in payload.trials[0],false);
    return new Response('{"ok":true}',{headers:{"content-type":"application/json"}});
  };
  await data.upload(s);
  assert.equal(attempts,0);
  s.trials.push({condition:"A",completed:true,total_rt_ms:510.22,image_id:"L1",clicks:[{result:"hit"}],gaze:[{x:2}]});
  s.completion_status="completed";
  await data.upload(s);
  assert.equal(attempts,1);
  assert.equal(s.upload.status,"sent");
  assert.equal(s.trials[0].gaze[0].x,2);
  await data.upload(s);
  assert.equal(attempts,1);
  const another = ()=>{
    const record = data.create(false);
    record.trials.push(...s.trials);
    record.completion_status = "completed";
    return record;
  };
  const offline = another();
  send = async ()=>{ throw new TypeError("offline"); };
  await data.upload(offline);
  assert.equal(offline.upload.status,"uncertain");
  const invalid = another();
  send = async ()=>new Response(null,{status:400});
  await data.upload(invalid);
  assert.equal(invalid.upload.status,"rejected");
  assert.match(D.csv([s]),/^\uFEFFproject_id,participant_id,session_id/);
  assert.match(D.csv([s]),/510.22/);
});
