import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {DatabaseSync} from "node:sqlite";
import {test} from "node:test";
import worker from "../allocator/worker.mjs";

test("shared allocation is sequential and retries do not take another slot",async()=>{
  const database = new DatabaseSync(":memory:");
  database.exec(readFileSync(new URL("../allocator/schema.sql",import.meta.url),"utf8"));
  const env = {DB:{prepare(sql) {
    const statement = database.prepare(sql);
    return {first:async()=>statement.get(),bind:id=>({first:async()=>statement.get(id)})};
  }}};
  const origin = "https://oneheijialun.github.io";
  const endpoint = "https://allocator.example/allocate";
  const request = (id,extra={})=>new Request(endpoint,{method:"POST",headers:{Origin:origin,"Content-Type":"application/json"},
    body:JSON.stringify({request_id:id,...extra})});
  const ids = Array.from({length:20},(_,i)=>(i+1).toString(16).padStart(32,"0"));
  assert.equal((await worker.fetch(new Request("https://allocator.example/health"),env)).status,200);
  const cors = await worker.fetch(new Request(endpoint,{method:"OPTIONS",headers:{Origin:origin}}),env);
  assert.equal(cors.status,204);
  assert.equal(cors.headers.get("Access-Control-Allow-Origin"),origin);
  assert.equal((await worker.fetch(request(ids[0],{student_id:"test-only"}),env)).status,400);
  assert.equal((await worker.fetch(new Request(endpoint),env)).status,403);
  const numbers = await Promise.all(ids.map(async id=>(await (await worker.fetch(request(id),env)).json()).sequence));
  assert.deepEqual(numbers,Array.from({length:20},(_,i)=>i+1));
  const retry = await (await worker.fetch(request(ids[3]),env)).json();
  assert.equal(retry.sequence,4);
  const next = await (await worker.fetch(request("e".repeat(32)),env)).json();
  assert.equal(next.sequence,21);
  assert.equal(database.prepare("SELECT COUNT(*) AS count FROM allocations").get().count,21);
  database.close();
});
