"use strict";

const fs = require("node:fs");
const path = require("node:path");

const dist = path.resolve(__dirname, "../dist");
const output = path.resolve(process.argv[2] || "visual-search-lab.html");
const mode = process.argv[3];
const preview = mode === "--preview";
let configuration = preview ? "\nLabConfig.preview = true;" : "";
if (mode === "--public") {
  const raw = process.env.LAB_ALLOCATION_URL || "";
  if (raw) {
    const url = new URL(raw);
    if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash) {
      throw new Error("LAB_ALLOCATION_URL 需要是可公开访问的 HTTPS 取号地址。");
    }
  }
  configuration = `\nLabConfig.allocation.required = true;\nLabConfig.allocation.endpoint = ${JSON.stringify(raw)};`;
}
const read = file => fs.readFileSync(path.join(dist, file), "utf8").replace(/^\uFEFF/, "");

if (output === path.join(dist, "index.html")) {
  throw new Error("请为单文件版使用与 dist/index.html 不同的路径。");
}

const types = {".svg":"image/svg+xml", ".png":"image/png"};
const assets = Object.fromEntries(fs.readdirSync(path.join(dist, "assets"))
  .filter(name => Object.hasOwn(types,path.extname(name)))
  .map(name => [name, `data:${types[path.extname(name)]};base64,` + fs.readFileSync(path.join(dist, "assets", name)).toString("base64")]));

const scripts = [`globalThis.LabAssetUrls = ${JSON.stringify(assets)};`];
let html = read("index.html").replace(/\s*<script defer src="([^"]+)"><\/script>/g, (_, file) => {
  scripts.push(read(file) + (file === "config.js" ? configuration : ""));
  return "";
});
html = html
  .replace('<link rel="stylesheet" href="styles.css">', () => `<style>\n${read("styles.css")}\n</style>`)
  .replace(/(src|href)="assets\/([^"]+\.(?:svg|png))"/g, (_, key, name) => `${key}="${assets[name]}"`)
  .replace("</body>", () => scripts.map(script =>
    `<script>\n${script.replace(/<\/script/gi, "<\\/script")}\n</script>`).join("\n") + "\n</body>");

fs.writeFileSync(output, html, "utf8");
console.log(output);
