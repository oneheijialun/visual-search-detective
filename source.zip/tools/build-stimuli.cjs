"use strict";

const fs = require("node:fs");
const path = require("node:path");

const W = 960;
const H = 600;
const out = path.join(__dirname, "../dist/assets");
const ink = "#3d4940";
const wood = "#976a4f";
const paleWood = "#bb8b64";
const light = "#f6efe2";
const stroke = "#596159";

function rect(x, y, w, h, fill, rx = 0, extra = "") {
  return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}" ${extra}/>`;
}
function ellipse(x, y, rx, ry, fill) {
  return `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${fill}"/>`;
}
function circle(x, y, r, fill, extra = "") {
  return `<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" ${extra}/>`;
}
function p(d, fill, extra = "") {
  return `<path d="${d}" fill="${fill}" ${extra}/>`;
}
function line(d, color = stroke, width = 3) {
  return p(d, "none", `stroke="${color}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round"`);
}
function at(x, y, art, s = 1) {
  return `<g transform="translate(${x} ${y}) scale(${s})">${art}</g>`;
}
function shadow(x, y, rx, ry) { return ellipse(x, y, rx, ry, "#56432c19"); }
function rug(x, y, color, scale = 1) {
  return at(x,y,p("M35 0H375L421 75Q427 90 405 90H4Q-9 90 0 77Z",color)
    + line("M34 13h344M27 24h359M10 72h393", "#fbf1d570", 2), scale);
}
function room(wall, floor, trim) {
  return rect(0,0,W,H,wall)
    + p("M0 0h135v405L0 442Z","#82746410")
    + rect(0,400,W,17,trim) + rect(0,417,W,183,floor)
    + line("M0 420h960M0 458h960M0 505h960M0 562h960M155 418l-95 182m300-182-25 182m234-182 41 182m174-182 105 182","#79674d26",2)
    + rect(0,0,W,H,"url(#room-light)");
}
function windowArt(x,y,w = 194,h = 164) {
  const innerW = w - 18;
  return at(x,y,rect(-5,3,w+10,h+12,"#675d4320",5) + rect(0,0,w,h,"#f7f2e1",4)
    + rect(9,9,innerW,h-18,"#b8d5d2",1)
    + p(`M9 ${h-51} Q${w*.25} ${h-89} ${w*.5} ${h-49}T${w-9} ${h-55}V${h-9}H9Z`,"#a1bdb0")
    + ellipse(w*.65,34,22,6,"#e9efe2") + ellipse(w*.28,52,18,5,"#e9efe2")
    + rect(w/2-3,8,6,h-16,"#f7f2e1") + rect(8,h/2-3,w-16,6,"#f7f2e1")
    + rect(-10,h-3,w+20,9,"#dfd0ae",2));
}
function frame(color = "#7a9b92", size = 1) {
  return at(0,0,rect(2,4,94,72,"#53433225",2) + rect(0,0,94,72,wood,3) + rect(5,5,84,62,"#f4e6c9",2)
    + rect(11,11,72,50,"#e6d8b8",1) + circle(62,27,10,color) + p("M12 60 37 26 63 60Z",color)
    + p("M45 60 65 37 82 60Z","#b1a585"),size);
}
function lamp(color = "#d6b16e", round = false) {
  const shade = round ? p("M0 30Q1 0 25 0Q49 0 50 30Z",color) : p("M8 0h34l8 30H0Z",color);
  return rect(23,22,4,45,"#76694e",2) + ellipse(25,67,17,4,"#76694e") + shade
    + line("M2 29h46","#9d80615c",1.5) + p("M11 4h11L16 26H7Z","#fff1d449");
}
function vase(color = "#b98672") {
  return p("M14 16h15c-3 9-1 11 6 18 12 13 6 27-13 27C4 61-1 48 8 36c6-7 9-12 6-20Z",color)
    + ellipse(21.5,16,8,2.6,"#725b54") + line("M21 16q2-9-1-15m4 14 8-10","#627b62",2)
    + ellipse(16,4,6,2.6,"#879675") + ellipse(35,6,5,2.5,"#7b9572");
}
function plant(size = 1) {
  return at(0,0,p("M33 66Q9 59 1 29Q24 25 35 52Q19 18 36 3Q50 22 42 50Q51 14 72 18Q70 44 46 62Q63 43 80 49Q67 68 45 70Z","#779776")
    + line("M41 73q-2-29-4-51m4 43L13 38m31 24 19-32","#526d54",1.7)
    + p("M17 67h48l-7 36H24Z","#bd896a") + rect(15,66,52,6,"#a9765d",2), size);
}
function book(color = "#788f91", w = 51) {
  return rect(0,0,w,11,color,2) + rect(3,2,w-6,5,"#e9ddbe",1) + rect(0,0,5,11,color,1);
}
function books() {
  return rect(0,8,11,48,"#ab795f",2) + rect(13,0,12,56,"#6e8b83",2)
    + rect(27,13,10,43,"#d2ad72",2) + rect(40,9,12,47,"#808992",2)
    + line("M3 47h5m8-3h6m8 1h4m9-2h6","#f4e7bf",1.2);
}
function shelf(x, y, width = 162) {
  return rect(x+8,y+6,width-16,10,"#76594235",1) + rect(x,y,width,9,paleWood,2)
    + rect(x+14,y+9,5,19,wood,1) + rect(x+width-19,y+9,5,19,wood,1);
}
function pillow(color) {
  return p("M0 3Q22-2 51 2Q47 17 52 36Q22 33 0 38Q5 20 0 3Z",color)
    + line("M8 8Q25 6 43 7M8 29q20-3 34 0","#fff8d14d",1.5);
}
function clock(color = "#aa815a", square = false) {
  const rim = square ? rect(0,0,54,54,color,8) : circle(27,27,27,color);
  const dial = square ? rect(5,5,44,44,"#eee5cf",5) : circle(27,27,22,"#eee5cf");
  return rim + dial + line("M27 14v13l10 5","#535b50",2.4)
    + [ [27,9],[45,27],[27,45],[9,27] ].map(([x,y])=>circle(x,y,1.3,"#7a7963")).join("");
}
function mug(color = "#8aa29a") {
  return p("M28 7h5q15 0 10 12-4 7-13 6", "none",`stroke="${color}" stroke-width="5"`)
    + p("M1 3h30l-2 25q-13 6-26 0Z",color) + ellipse(16,4,15,3.6,"#e9dbc0")
    + ellipse(16,4,11,2,"#6c6253") + line("M7 10l2 14","#fff0d980",2);
}
function plate(color = "#b3c1a9") {
  return ellipse(30,11,29,10,color) + ellipse(30,10,21,6,"#e5dfca")
    + ellipse(30,10,14,3,"#d6d4bf");
}
function kettle(color = "#798e90") {
  return line("M15 27Q10 0 39 4Q64 6 57 32",ink,5) + p("M13 21h45l4 28q-24 9-53 0Z",color)
    + p("M13 35 1 20 0 31 12 48Z",color) + ellipse(35,20,23,4,"#586a67") + rect(31,13,9,5,ink,2);
}
function pencilCup(color = "#b38965") {
  return line("M8 20 2 3m12 19L13 1m7 22 8-18","#6e8b83",3)
    + p("M0 16h28l-4 25H4Z",color) + ellipse(14,16,14,2.5,"#755d4d");
}
function fruit(extra = true) {
  return circle(11,11,9,"#d3a660") + circle(25,9,9,"#aa795f")
    + (extra ? circle(39,12,9,"#b1a05f") : "") + p("M0 14h51Q46 30 26 31Q5 30 0 14Z","#8e9d88");
}
function alarm(square = false) {
  return line("M13 38 9 47m24-9 5 9",ink,3) + ellipse(10,4,8,3,"#ad8564") + ellipse(36,4,8,3,"#ad8564")
    + at(2,2,clock("#ad8564",square),.78);
}
function note(color = "#c5a066") {
  return p("M1 4 26 0l5 24-24 6Z",color) + line("M8 10l13-2M9 15l10-2","#6e664f",1.4) + circle(13,2,2,"#657c6b");
}
function target(id, label, icon, kind, x,y,w,h, a,b) {
  return {id,label,icon,kind,box:[x,y,w,h],a,b};
}
function living(v) {
  const wall = v ? "#e4e4d4" : "#e9e1cc";
  const sofa = v ? "#849692" : "#899b7d";
  const base = room(wall,"#caa783","#c4b594") + rug(259,494,v?"#ac8c79":"#aa927b",1.14)
    + windowArt(652,95,197,172) + shelf(89,238,174) + at(105,182,books())
    + at(199,195,plant(.42)) + shadow(470,475,277,23) + rect(231,446,17,36,wood,3)
    + rect(656,446,17,36,wood,3) + rect(230,291,450,161,sofa,36)
    + rect(247,307,203,92,"#dce1c52b",16) + rect(455,307,207,92,"#dce1c52b",16)
    + rect(222,389,468,64,"#5a70642c",23) + rect(214,346,50,99,sofa,18)
    + rect(653,346,50,99,sofa,18) + rect(265,401,388,48,sofa,14)
    + at(592,343,pillow("#d0b18a"),1.02) + rect(721,382,114,10,paleWood,3)
    + rect(730,390,8,82,wood,2) + rect(818,390,8,82,wood,2)
    + shadow(481,547,157,14) + rect(377,492,11,58,wood,3) + rect(577,491,10,60,wood,3)
    + p("M356 472h248l23 31H333Z","#c19772") + p("M333 503h294v8H333Z",wood)
    + at(92,365,plant(.97)) + at(543,475,plate(),.64);
  return {base:base + (v ? at(411,139,frame("#9c9477")) + at(754,310,lamp("#c5a879")) + at(484,425,vase("#a0866e"),.83) :
      at(286,350,pillow("#b78d72")) + at(554,146,clock("#9e805e"),.8)),
    decoys:["沙发","窗户","墙上置物架"], targets:v ? [
      target("cushion","靠垫","pillow","color",281,344,62,50,at(286,350,pillow("#b78d72")),at(286,350,pillow("#7d969a"))),
      target("book","书本","book","presence",382,472,64,22,"",at(388,477,book("#a08069"),.95)),
      target("clock","挂钟","clock","form",554,143,58,59,at(557,147,clock()),at(557,147,clock("#aa815a",true)))
    ] : [
      target("picture","挂画","frame","color",405,131,108,86,at(411,139,frame("#7a9b92")),at(411,139,frame("#b28478"))),
      target("lamp","台灯","lamp","presence",752,307,58,80,at(754,310,lamp()),""),
      target("vase","花瓶","vase","position",439,424,75,59,at(442,426,vase("#ad846f"),.82),at(479,426,vase("#ad846f"),.82))
    ]};
}
function kitchen(v) {
  const cab = v ? "#ab9b79" : "#889c90";
  const base = room(v?"#e9e1cd":"#e2e6db","#c9ae8d","#c0b19a")
    + rect(283,214,595,106,"#f3ebd9") + line("M283 239h595m-595 27h595m-595 27h595M307 214v106m53-106v106m53-106v106m53-106v106m53-106v106m53-106v106m53-106v106m53-106v106m53-106v106m53-106v106m53-106v106","#b5a99552",1)
    + shadow(182,463,123,22) + rect(90,185,171,264,"#a8b0a5",12) + rect(98,185,155,257,"#c5c9ba",10)
    + line("M101 285h149M113 224v38m0 41v37","#78897e",5)
    + rect(292,320,584,122,cab,3) + rect(282,309,605,14,"#a97e60",3)
    + [309,418,527,636,745].map(x=>rect(x,335,98,96,"#ffffff17",3)+line(`M${x+37} 346h25`,"#6d7263",3)).join("")
    + rect(294,432,580,10,"#63736b55") + windowArt(578,88,158,133)
    + shelf(302,211,199) + at(330,178,plate("#bab694"),.8) + at(399,157,plant(.51))
    + line("M648 309v-22q0-20 16-20 15 0 15 16","#7e8a81",5)
    + ellipse(667,309,48,7,"#727f75") + rect(788,283,68,23,"#9d886d",3)
    + rect(776,109,98,101,cab,5) + line("M825 114v91m-9-32v19m17-19v19","#5c6b614c",2.5)
    + shadow(542,557,230,24) + rect(366,493,12,76,wood,3) + rect(697,493,13,76,wood,3)
    + p("M365 442h345l38 46H327Z","#c79971") + rect(327,488,421,10,wood,2)
    + at(527,448,plate("#ada785"),.62);
  return {base:base + (v ? at(680,444,mug("#809b92"),.9) + at(160,235,note("#9e9f82")) + at(568,465,plate("#b6b69a"),.75) :
      at(428,444,fruit(false)) + at(450,359,rect(0,0,32,6,"#826f5e",3)) + at(750,261,kettle(),.93)),
    decoys:["窗户","水槽","墙上置物架"], targets:v ? [
      target("fruit","果碗","fruit","presence",421,435,67,45,at(428,444,fruit()),at(428,444,fruit(false))),
      target("handle","橱柜把手","handle","color",445,353,44,20,at(450,359,rect(0,0,32,6,"#786756",3)),at(450,359,rect(0,0,32,6,"#ded4af",3))),
      target("kettle","水壶","kettle","position",721,258,94,58,at(723,261,kettle(),.92),at(753,261,kettle(),.92))
    ] : [
      target("mug","杯子","mug","color",674,437,55,46,at(680,444,mug("#809b92"),.9),at(680,444,mug("#b78469"),.9)),
      target("magnet","冰箱贴","note","presence",153,229,46,42,at(160,235,note()),""),
      target("plate","盘子","plate","position",562,458,102,27,at(568,465,plate(),.8),at(611,465,plate(),.8))
    ]};
}
function study(v) {
  const base = room(v?"#e4e0d1":"#e1e5da","#bda285","#b6ad92")
    + rug(290,476,v?"#929d8a":"#ad987e",1.2) + windowArt(647,98,178,162)
    + rect(90,160,149,278,"#8d6c55",5) + rect(97,166,135,262,"#d2b18e",2)
    + rect(102,170,126,250,"#a98b70",2)
    + [237,302,365].map(y=>rect(98,y,134,8,"#d2ad84",2)).join("")
    + at(109,181,books()) + at(177,257,plant(.42)) + at(113,290,book("#758883",80))
    + at(118,349,book("#a37963",66)) + at(121,338,book("#919d82",60))
    + rect(113,379,90,39,"#b49373",4) + line("M147 390h22","#725b4c",3)
    + shadow(529,503,290,22) + rect(299,391,12,105,wood,3) + rect(789,391,12,105,wood,3)
    + rect(716,399,78,79,"#ad8466",3) + line("M718 424h73m-72 27h73m-51-40h23m-23 26h23m-23 25h23","#7c644f",2)
    + p("M295 369h500l23 17H277Z","#c29a76") + rect(277,386,541,13,wood,3)
    + rect(443,232,151,97,"#53655d",7) + rect(449,238,139,85,"#d2dcd3",3)
    + rect(510,329,16,32,"#69766a",2) + rect(481,361,76,7,"#69766a",3)
    + p("M461 373h112l11 10H451Z","#d4c3a7") + ellipse(607,379,12,5,"#786f60")
    + shadow(527,547,91,12) + rect(522,484,11,56,ink,4) + line("M491 541h74",ink,7)
    + rect(467,440,126,49,"#677b6c",12) + rect(468,401,124,65,"#8c9f8b",16)
    + at(837,371,plant(.98)) + shelf(306,205,112) + at(362,171,note("#aaa078"));
  return {base:base + (v ? at(323,360,book("#7e978a",65)) + at(734,306,lamp("#b7a271")) :
      rect(460,253,106,54,"#95ada2",2) + at(382,98,clock("#9f8566"),.91) + at(508,422,pillow("#b19477"),.66)),
    decoys:["窗户","书架","键盘"], targets:v ? [
      target("screen","屏幕","screen","color",455,247,117,65,rect(460,253,106,54,"#95ada2",2),rect(460,253,106,54,"#bd9b8c",2)),
      target("cushion","靠垫","pillow","presence",501,415,52,37,at(508,422,pillow("#b19477"),.66),""),
      target("clock","挂钟","clock","position",372,91,98,62,at(379,98,clock("#9f8566"),.91),at(415,98,clock("#9f8566"),.91))
    ] : [
      target("book","书本","book","color",316,353,79,26,at(323,360,book("#7e978a",65)),at(323,360,book("#b08069",65))),
      target("cup","笔筒","cup","presence",633,325,44,50,"",at(640,330,pencilCup())),
      target("lamp","台灯","lamp","form",730,302,61,75,at(734,306,lamp("#b7a271")),at(734,306,lamp("#b7a271",true)))
    ]};
}
function bedroom(v) {
  const bed = v ? "#8d9c94" : "#a7a184";
  const base = room(v?"#e9e0d4":"#e4e3d4","#c8a687","#bdb193")
    + rug(236,483,v?"#a79188":"#9da390",1.18) + windowArt(665,87,170,152)
    + rect(97,143,160,296,"#a17e63",7) + rect(104,152,146,278,"#ba9778",4)
    + line("M176 155v272m-14-145v33m27-33v33","#826a57",3) + rect(111,175,51,92,"#c7a383",3)
    + rect(190,175,51,92,"#c7a383",3) + shadow(509,495,300,25)
    + rect(325,275,359,145,"#9a755c",25) + rect(337,287,335,125,"#ad866a",20)
    + line("M372 304v62m44-62v62m44-62v62m44-62v62m44-62v62m44-62v62m44-62v62","#70574342",3)
    + rect(310,475,25,36,wood,3) + rect(667,475,25,36,wood,3)
    + p("M344 355h318l64 101H285Z","#e7e0c8") + rect(285,450,441,43,"#8e725e",11)
    + p("M325 401h359l42 55H285Z",bed) + rect(286,446,439,38,bed,9)
    + line("M293 451h423m-411 18h400","#fff9e35e",2.5) + at(376,356,pillow("#e1d6b9"),1.62)
    + rect(743,379,117,91,"#b58c68",4) + rect(735,373,132,10,"#9d775b",3)
    + rect(752,390,99,30,"#c09976",3) + rect(752,426,99,30,"#c09976",3)
    + line("M786 405h28m-28 34h28","#735b49",3) + rect(747,466,10,22,wood,2) + rect(846,466,10,22,wood,2)
    + rect(208,387,83,8,paleWood,3) + rect(215,394,7,76,wood,2) + rect(277,394,7,76,wood,2)
    + at(118,389,plant(.87));
  const pattern = color => line("M370 418l-6 15m34-15-5 15m35-15-3 15m34-15-2 15m33-15v15m31-15 1 15m31-15 3 15m31-15 4 15m32-15 6 15",color,3);
  return {base:base + (v ? at(220,330,lamp("#b4a77a"),.79) + at(447,143,frame("#7f9a89"),.88) :
      pattern("#ece3c59c") + at(791,330,alarm(),.89) + at(537,348,pillow("#d9d0b7"),1.54)),
    decoys:["衣柜","窗户","地毯"], targets:v ? [
      target("blanket","被面图案","blanket","form",354,409,296,32,pattern("#ece3c59c"),
        line("M364 420h277m-274 12h276","#ece3c59c",3)),
      target("alarm","闹钟","alarm","form",784,324,57,52,at(791,330,alarm(),.89),at(791,330,alarm(true),.89)),
      target("pillow","枕头","pillow","presence",530,342,97,66,at(537,348,pillow("#d9d0b7"),1.54),"")
    ] : [
      target("lamp","床头灯","lamp","color",215,326,51,64,at(220,330,lamp("#b4a77a"),.79),at(220,330,lamp("#a78178"),.79)),
      target("vase","花瓶","vase","presence",759,320,45,56,"",at(766,323,vase("#889787"),.81)),
      target("picture","挂画","frame","position",436,136,130,81,at(443,143,frame("#7f9a89"),.88),at(477,143,frame("#7f9a89"),.88))
    ]};
}
function practice() {
  return {base:room("#e4e6d7","#c6a889","#bdb39a") + rug(269,477,"#a8a085",1.08)
      + windowArt(632,102,207,173) + shadow(480,528,297,20)
      + rect(241,414,15,116,wood,4) + rect(708,414,15,116,wood,4)
      + rect(226,396,510,29,paleWood,4) + rect(233,422,495,10,wood,2)
      + at(133,397,plant(1.07)) + at(657,352,books(),.78) + at(440,379,plate(),.93)
      + shelf(93,223,166) + at(114,166,books()),
    decoys:["桌子","窗户","盆栽"], targets:[
      target("art","挂画","frame","color",355,133,110,88,at(361,140,frame("#80968b")),at(361,140,frame("#b18175"))),
      target("lamp","台灯","lamp","presence",282,315,78,84,at(292,320,lamp(),1.09),""),
      target("vase","花瓶","vase","position",529,327,106,77,at(536,332,vase()),at(586,332,vase()))
    ]};
}

const specs = [
  ["L1","客厅",living,false], ["L2","客厅",living,true],
  ["K1","厨房",kitchen,false], ["K2","厨房",kitchen,true],
  ["O1","书房",study,false], ["O2","书房",study,true],
  ["B1","卧室",bedroom,false], ["B2","卧室",bedroom,true],
  ["P0","练习场景",practice,false]
];

function svg(w, h, content) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${content}</svg>\n`;
}
const roomLight = '<defs><linearGradient id="room-light" x1="0" x2="1" y1="0" y2="1" gradientUnits="objectBoundingBox"><stop stop-color="#fff9df" stop-opacity=".15"/><stop offset="1" stop-color="#83877f" stop-opacity=".08"/></linearGradient></defs>';
const pairs = {};
fs.mkdirSync(out, {recursive:true});
for (const [id,scene,make,mirror] of specs) {
  const {base,targets,decoys} = make(mirror);
  for (const frame of ["a","b"]) {
    const shapes = `<g id="base">${base}</g>` + targets.map(t=>`<g id="change-${t.id}">${t[frame]}</g>`).join("");
    const art = mirror ? `<g transform="translate(${W} 0) scale(-1 1)">${shapes}</g>` : shapes;
    fs.writeFileSync(path.join(out,`${id}_${frame.toUpperCase()}.svg`), svg(W,H,roomLight+art));
  }
  pairs[id] = {id,scene,decoys,targets:targets.map(({id,label,icon,kind,box:[x,y,w,h]})=>({
    id,label,icon,kind,box:[mirror ? W-x-w : x,y,w,h]
  }))};
}

// Generic, monochrome object symbols. These never reveal a variant's color, position, or quantity.
const symbols = {
  frame:"M9 12h46v39H9z M14 17h36v29H14z M17 41l10-13 8 9 5-5 7 9 M40 24h.1",
  lamp:"M20 13h24l7 22H13z M32 35v16 M22 51h20",
  vase:"M25 14h14m-11 1v10c0 4-12 8-12 17 0 6 6 10 16 10s16-4 16-10c0-9-12-13-12-17V15",
  pillow:"M11 19q20 3 42 0-3 13 0 27-20-3-42 0 3-14 0-27Z M17 24l4 4m26-4-4 4m4 14-4-4m-26 4 4-4",
  book:"M17 14h32v34H18q-7 0-7-6V20q0-6 6-6Zm-6 28q0-5 7-5h31M22 21h17m-17 6h11",
  clock:"M54 32a22 22 0 1 1-44 0 22 22 0 0 1 44 0ZM32 19v13l10 5",
  mug:"M13 20h31v22q0 8-9 8H22q-9 0-9-8Zm31 4h4q8 0 8 7t-12 8",
  note:"M16 19h32v29H16z M24 28h16m-16 8h12m-4-17v-7",
  plate:"M56 33c0 9-11 16-24 16S8 42 8 33s11-16 24-16 24 7 24 16Zm-9 0c0 5-7 9-15 9s-15-4-15-9 7-9 15-9 15 4 15 9Z",
  fruit:"M8 33h48q-4 17-24 17T8 33Zm8-1a8 8 0 0 1 13-8m1 8q2-16 13-12 8 3 6 12m-15-10q0-8 7-9",
  handle:"M12 18h40v30H12z M21 27v9m22-9v9m-22-4h22",
  kettle:"M15 26h31l4 23H14l-4-19 5 3m4-8q-2-13 12-13 12 0 12 13m-29 9-7-6 4 13",
  screen:"M9 14h46v30H9z M32 44v8m-11 0h22",
  cup:"M18 27h28l-4 24H22z M25 26l-4-12m11 12V11m7 15 6-11",
  blanket:"M12 21q19-12 40 0v22q-21-11-40 0z M16 28q15-7 31 0m-31 7q15-7 31 0",
  alarm:"M50 32a18 18 0 1 1-36 0 18 18 0 0 1 36 0ZM32 22v10l7 5m-23-20-5-5m37 5 5-5M20 47l-4 7m28-7 4 7"
};
for (const [name, d] of Object.entries(symbols)) {
  fs.writeFileSync(path.join(out,`icon-${name}.svg`), svg(64,64,line(d,"#245443",2.6)));
}
fs.writeFileSync(path.join(out,"stimuli.js"), `"use strict";\nglobalThis.LabStimuli = ${JSON.stringify({width:W,height:H,pairs},null,2)};\n`);


