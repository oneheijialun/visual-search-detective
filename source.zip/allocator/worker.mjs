const pagesOrigin = "https://oneheijialun.github.io";
const sql = `INSERT INTO allocations (request_id) VALUES (?)
  ON CONFLICT(request_id) DO UPDATE SET request_id = excluded.request_id
  RETURNING sequence`;

function json(body,status,headers={}) {
  return Response.json(body,{status,headers:{"Cache-Control":"no-store",...headers}});
}

export default {
  async fetch(request,env) {
    const path = new URL(request.url).pathname;
    const origin = request.headers.get("Origin");
    const allowed = env.ALLOWED_ORIGIN || pagesOrigin;
    const cors = {"Access-Control-Allow-Origin":allowed,Vary:"Origin"};
    if (path === "/health" && request.method === "GET") {
      try {
        await env.DB.prepare("SELECT 1 FROM allocations LIMIT 1").first();
        return json({ready:true},200,cors);
      } catch {
        return json({ready:false},503,cors);
      }
    }
    if (path !== "/allocate") return json({error:"not_found"},404);
    if (origin !== allowed) return json({error:"origin_denied"},403);
    if (request.method === "OPTIONS") {
      return new Response(null,{status:204,headers:{...cors,
        "Access-Control-Allow-Methods":"POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"}});
    }
    if (request.method !== "POST") return json({error:"method_not_allowed"},405,cors);
    if (!request.headers.get("Content-Type")?.toLowerCase().startsWith("application/json")) {
      return json({error:"invalid_content_type"},415,cors);
    }
    if (Number(request.headers.get("Content-Length")) > 128) return json({error:"invalid_request"},400,cors);
    let body;
    try {
      const raw = await request.text();
      if (raw.length > 128) return json({error:"invalid_request"},400,cors);
      body = JSON.parse(raw);
    } catch {
      return json({error:"invalid_request"},400,cors);
    }
    if (!body || Object.keys(body).length !== 1 || typeof body.request_id !== "string" ||
        !/^[a-f0-9]{32}$/.test(body.request_id)) {
      return json({error:"invalid_request"},400,cors);
    }
    try {
      const row = await env.DB.prepare(sql).bind(body.request_id).first();
      return json({sequence:row.sequence},200,cors);
    } catch {
      return json({error:"allocator_unavailable"},503,cors);
    }
  }
};
